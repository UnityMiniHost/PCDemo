# WebGLHost Runtime PC

WebGLHost Runtime PC 是一个用于在 PC 平台上运行 WebGL 小游戏的宿主运行时环境。基于 Electron 技术栈，它提供了完整的游戏生命周期管理、UI 界面、网络通信、文件系统等功能。

## 特性

- **多实例管理**: 支持同时运行多个游戏实例
- **生命周期管理**: 完整的游戏启动、暂停、恢复、停止流程
- **UI 组件**: 提供胶囊按钮、加载界面、Toast、Modal 等 UI 组件
- **网络通信**: 支持 HTTP 请求、WebSocket、文件下载等
- **文件系统**: 虚拟文件路径映射，支持用户数据存储
- **调试支持**: 集成 Web Inspector、vConsole 等调试工具
- **性能监控**: 内存、CPU、FPS、卡顿等性能指标上报
- **音频系统**: 通过TJGameHandle接口实现音频控制
- **隐私保护**: 隐私权限检查和数据保护

## 安装

```bash
npm install webglhost-runtime-pc
```

## 快速开始

### 基本使用

```javascript
const { TJHostHandle, RuntimeGameHandle, MultiGameLauncher } = require('webglhost-runtime-pc');

// 1. 初始化SDK
const hostHandle = await TJHostHandle.initialize('your-sdk-key', 'your-sdk-secret');

// 2. 创建游戏句柄
const gameHandle = await hostHandle.createGameHandle();

// 3. 设置游戏启动选项
await gameHandle.setGameStartOptions({
  launchKey: 'your-game-launch-key',
  userId: 'user-id'
});

// 4. 启动游戏
await gameHandle.start();

// 5. 开始游戏
await gameHandle.play();
```

### 多实例管理

```javascript
// 配置最大实例数
MultiGameLauncher.configMaxGame(3);

// 启动多个游戏实例
const game1 = await MultiGameLauncher.launch('game1', {
  sdkKey: 'your-sdk-key',
  sdkSecret: 'your-sdk-secret',
  launchKey: 'game1-launch-key',
  userId: 'user-id'
});

const game2 = await MultiGameLauncher.launch('game2', {
  sdkKey: 'your-sdk-key',
  sdkSecret: 'your-sdk-secret',
  launchKey: 'game2-launch-key',
  userId: 'user-id'
});

// 全局控制
await MultiGameLauncher.pauseAll();
await MultiGameLauncher.resume('game1');
await MultiGameLauncher.stopAll();
```

### 事件监听

```javascript
// 设置游戏菜单点击事件
gameHandle.setOnTJMenuListener((view) => {
  console.log('Menu clicked');
});

// 设置游戏关闭按钮点击事件
gameHandle.setOnTJCloseListener((view) => {
  console.log('Close clicked');
});

// 设置首帧渲染回调
gameHandle.setOnFirstFrameRenderedListener(() => {
  console.log('First frame rendered');
});

// 设置小游戏崩溃回调
gameHandle.setOnHostFailureListener((error) => {
  console.log('Game crashed:', error);
});
```

### 自定义命令

```javascript
// 设置自定义命令监听
gameHandle.setCustomCommandListener('customCommand', (request, handle) => {
  console.log('Custom command received:', request);
  handle.success({ result: 'success' });
});

// 运行自定义脚本
await gameHandle.runCustomScript(`
  console.log('Hello from game!');
  tj.customCommand({
    command: 'customCommand',
    data: { message: 'Hello from game!' }
  });
`);
```

### 音频控制

```javascript
// 游戏静音
gameHandle.muteAllAudio();

// 取消静音
gameHandle.unmuteAllAudio();

// 切换静音状态
gameHandle.toggleAudioMute();

// 检查是否静音
const isMuted = gameHandle.isMuted();
```

### 文件系统

```javascript
// 注入文件系统规则
gameHandle.injectFileSystemRule('/userData', '/path/to/user/data');

// 路径转换
const maskPath = gameHandle.convertRealPathToMaskPath('/path/to/user/data/file.txt');
const realPath = gameHandle.convertMaskPathToRealPath('/userData/file.txt');
```

### 调试功能

```javascript
// 打开调试菜单
gameHandle.showDebugMenu();

// 切换调试模式
gameHandle.toggleDebugMode();

// 获取调试模式状态
const debugEnabled = gameHandle.getDebugModeStatus();

// 强制垃圾回收
gameHandle.invokeForceGC();

// 导出日志
gameHandle.exportLogManagerLog();
```

## API 参考

### TJHostHandle

#### 静态方法

- `initialize(sdkKey, sdkSecret, options)` - 初始化SDK
- `getVersionName()` - 获取版本名称
- `getVersionCode()` - 获取版本代码
- `getCommitId()` - 获取提交ID
- `setRuntimeEnv(env)` - 设置运行时环境

#### 实例方法

- `createGameHandle(options)` - 创建游戏句柄
- `getUserHistory(userId)` - 获取用户历史记录
- `setHistorySaver(saver)` - 设置历史记录保存器
- `initLog(level, printer)` - 初始化日志
- `cleanup()` - 清理资源

### RuntimeGameHandle

#### 生命周期方法

- `initialize(options)` - 初始化游戏句柄
- `setGameStartOptions(options)` - 设置游戏启动选项
- `start()` - 启动游戏
- `play()` - 开始游戏
- `pause()` - 暂停游戏
- `stop()` - 停止游戏
- `destroy()` - 销毁游戏
- `restart()` - 重启游戏

#### 状态查询

- `getGameView()` - 获取游戏视图
- `getGameState()` - 获取游戏状态
- `isMuted()` - 检查是否静音

#### 音频控制

- `muteAllAudio()` - 开启静音
- `unmuteAllAudio()` - 关闭静音
- `toggleAudioMute()` - 切换静音

#### 事件监听

- `setOnTJMenuListener(callback)` - 设置菜单点击事件
- `setOnTJCloseListener(callback)` - 设置关闭按钮事件
- `setOnFirstFrameRenderedListener(callback)` - 设置首帧渲染事件
- `setOnHostFailureListener(callback)` - 设置崩溃事件

#### 自定义功能

- `setCustomCommandListener(name, callback)` - 设置自定义命令
- `runCustomScript(script, callback)` - 运行自定义脚本
- `setPrivacyChecker(checker)` - 设置隐私检测器

#### 文件系统

- `injectFileSystemRule(maskPath, realPath)` - 注入文件系统规则
- `convertRealPathToMaskPath(realPath)` - 真实路径转虚拟路径
- `convertMaskPathToRealPath(maskPath)` - 虚拟路径转真实路径

#### 调试功能

- `showDebugMenu()` - 显示调试菜单
- `toggleDebugMode()` - 切换调试模式
- `getDebugModeStatus()` - 获取调试模式状态
- `invokeForceGC()` - 强制垃圾回收
- `exportLogManagerLog()` - 导出日志

### MultiGameLauncher

#### 静态方法

- `configMaxGame(max)` - 配置最大实例数
- `launch(gameId, options)` - 启动游戏实例
- `createGameHandle(hostHandle, gameId, options, completion)` - 创建游戏句柄
- `stopAll()` - 停止所有实例
- `stop(gameId)` - 停止指定实例
- `pauseAll()` - 暂停所有实例
- `pause(gameId)` - 暂停指定实例
- `resume(gameId, enterOption)` - 恢复指定实例
- `destroyAll()` - 销毁所有实例
- `destroy(gameId)` - 销毁指定实例

#### 查询方法

- `getGameHandle(gameId)` - 获取游戏句柄
- `getAllTasks()` - 获取所有任务
- `getActiveGameCount()` - 获取活跃游戏数量
- `isMaxReached()` - 检查是否达到最大实例数

## 错误处理

```javascript
const { HostRuntimeError } = require('webglhost-runtime-pc');

try {
  const hostHandle = await TJHostHandle.initialize('invalid-key', 'invalid-secret');
} catch (error) {
  if (error instanceof HostRuntimeError) {
    switch (error.code) {
      case 'SDK_INITIALIZATION_FAILED':
        console.log('SDK初始化失败');
        break;
      case 'GAME_ID_NOT_SET':
        console.log('游戏ID未设置');
        break;
      case 'LAUNCH_KEY_NOT_SET':
        console.log('启动密钥未设置');
        break;
      default:
        console.log('未知错误:', error.message);
    }
  }
}
```

## 配置选项

### TJHostHandle.initialize 选项

```javascript
const options = {
  // 网络配置
  timeout: 30000,           // 请求超时时间（毫秒）
  retryCount: 3,            // 重试次数
  
  // 日志配置
  logLevel: 'info',         // 日志级别
  enableConsoleLog: true,   // 启用控制台日志
  
  // 调试配置
  enableDebug: false,       // 启用调试模式
  enableVConsole: false,    // 启用vConsole
  
  // 性能配置
  enablePerformanceMonitor: true,  // 启用性能监控
  performanceReportInterval: 5000, // 性能上报间隔（毫秒）
};
```

### setGameStartOptions 选项

```javascript
const gameOptions = {
  launchKey: 'game-launch-key',    // 游戏启动密钥
  userId: 'user-id',               // 用户ID
  gameId: 'game-id',               // 游戏ID
  
  // 游戏配置
  enableVConsole: false,           // 启用vConsole
  enableWebInspector: false,       // 启用Web Inspector
  
  // 窗口配置
  width: 800,                      // 窗口宽度
  height: 600,                     // 窗口高度
  resizable: true,                 // 可调整大小
  fullscreen: false,               // 全屏模式
  
  // 文件系统配置
  userDataPath: '/userData',       // 用户数据路径
  gameDataPath: '/gameData',       // 游戏数据路径
};
```

## 开发指南

### 项目结构

```
webglhost-runtime/
├── index.js                 # 主入口文件
├── TJHostHandle.js          # 宿主句柄
├── RuntimeGameHandle.js     # 游戏运行时句柄
├── MultiGameLauncher.js     # 多游戏启动器
├── GameDevelopmentKit.js    # 游戏开发套件
├── GameUIKit.js             # 游戏UI套件
├── model/                   # 数据模型
│   ├── HostRuntimeError.js
│   ├── RuntimeState.js
│   └── MiniGameLaunchOption.js
├── utils/                   # 工具类
│   ├── RuntimeLogger.js
│   ├── HttpUtil.js
│   └── ReportAgent.js
├── config/                  # 配置文件
│   └── TJConstants.js
└── package.json
```

### 扩展开发

#### 自定义UI组件

```javascript
class CustomToastView {
  show(window, title, duration) {
    // 实现自定义Toast显示逻辑
  }
  
  hide() {
    // 实现自定义Toast隐藏逻辑
  }
}

// 在GameUIKit中使用
gameUIKit.toastView = new CustomToastView();
```

#### 自定义网络请求

```javascript
class CustomHttpUtil {
  async request(options) {
    // 实现自定义网络请求逻辑
  }
}

// 在GameDevelopmentKit中使用
developmentKit.httpUtil = new CustomHttpUtil();
```



## 测试

```bash
# 运行所有测试
npm test

# 运行测试并监听文件变化
npm run test:watch

# 生成测试覆盖率报告
npm run test:coverage
```

## 构建

```bash
# 生产环境构建
npm run build

# 开发环境构建
npm run build:dev
```

## 更新日志

### v1.0.0

- 初始版本发布
- 支持基本的游戏生命周期管理
- 支持多实例管理
- 支持音频系统
- 支持文件系统
- 支持调试功能 